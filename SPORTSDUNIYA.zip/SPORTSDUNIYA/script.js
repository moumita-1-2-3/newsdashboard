// script.js

document.addEventListener('DOMContentLoaded', () => {
    // Check login status on page load
    if (localStorage.getItem('isLoggedIn') === 'true') {
        // User is logged in, you can perform actions like showing user-specific content
        console.log("User is logged in");
    }

    const loginButton = document.getElementById('loginButton');

    loginButton.addEventListener('click', () => {
        window.location.href = 'login.html';
    });
    // ... (rest of the script.js code from previous response)
    document.addEventListener('DOMContentLoaded', () => {
        // Check login status on page load (same as above)
    
        const loginButton = document.getElementById('loginButton');
        const modal = document.getElementById('loginModal');
        const modalLoginForm = document.getElementById('modalLoginForm');
        const closeBtn = document.getElementsByClassName("close")[0];
    
        loginButton.addEventListener('click', () => {
            modal.style.display = "block";
        });
    
        closeBtn.onclick = function() {
            modal.style.display = "none";
        }
    
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
    
        modalLoginForm.addEventListener('submit', (event) => {
            event.preventDefault();
            const email = document.getElementById('modalEmail').value;
            const password = document.getElementById('modalPassword').value;
            if (email === "test@example.com" && password === "password") {
                localStorage.setItem('isLoggedIn', 'true'); //Store login status
                modal.style.display = "none";
                alert("Login Successful");
            } else {
                alert("Invalid credentials");
            }
        });
    
        // ... (rest of the script.js code)
    });
});
document.addEventListener('DOMContentLoaded', () => {
    const newsContainer = document.getElementById('newsContainer');
    const payoutTotal = document.getElementById('payoutTotal');
    const payoutPerArticleInput = document.getElementById('payoutPerArticle');
    const savePayoutButton = document.getElementById('savePayout');
    let payoutPerArticle = localStorage.getItem('payoutPerArticle') || 0;
    payoutPerArticleInput.value = payoutPerArticle;

    savePayoutButton.addEventListener('click', () => {
        payoutPerArticle = parseFloat(payoutPerArticleInput.value) || 0;
        localStorage.setItem('payoutPerArticle', payoutPerArticle);
        calculatePayout();
    });

    fetchNews();

    async function fetchNews() {
        // Replace with your actual API key
        const apiKey = 'f663ec31c166493bb33919497ec5fd15';
        const apiUrl = `https://newsapi.org/v2/everything?q=tesla&from=2024-12-05&sortBy=publishedAt&apiKey=f663ec31c166493bb33919497ec5fd15=${apiKey}`; // Example using News API

        try {
            const response = await fetch(apiUrl);
            const data = await response.json();
            displayNews(data.articles);
        } catch (error) {
            console.error('Error fetching news:', error);
            newsContainer.innerHTML = '<p>Error fetching news.</p>';
        }
    }

    function displayNews(articles) {
        newsContainer.innerHTML = '';
        articles.forEach(article => {
            const newsItem = document.createElement('div');
            newsItem.classList.add('news-item');
            newsItem.innerHTML = `
                <h3>${article.title}</h3>
                <p>${article.description}</p>
                <p>Author: ${article.author || 'Unknown'}</p>
                <p>Date: ${article.publishedAt}</p>
            `;
            newsContainer.appendChild(newsItem);
        });
        calculatePayout();
    }

    function calculatePayout() {
        const numArticles = document.querySelectorAll('.news-item').length;
        const totalPayout = numArticles * payoutPerArticle;
        payoutTotal.textContent = `Total: $${totalPayout.toFixed(2)}`;
    }

    
    //Implement filtering, search, export functionalities here (PDF, CSV, Google Sheets)
    //Use libraries like jsPDF or html2canvas for PDF export
    //Use a CSV library or manual string formatting for CSV export
    //Google Sheets integration will require OAuth and the Google Sheets API.
});